package com.onehundredmillion.library.domain;

public enum ReservationStatus {
    RESERVATION,CANCEL;
}