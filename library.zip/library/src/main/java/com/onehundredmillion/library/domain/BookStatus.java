package com.onehundredmillion.library.domain;

public enum BookStatus {
    RENT,ReturnBook,RESERVATION,CANCEL,LIKE,DISLIKE;
}