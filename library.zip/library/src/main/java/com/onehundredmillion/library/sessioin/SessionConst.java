package com.onehundredmillion.library.sessioin;

public class SessionConst {
    public static final String LOGIN_MEMBER = "loginMember";
}