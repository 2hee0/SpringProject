package com.onehundredmillion.library.service;

import org.springframework.stereotype.Service;

@Service
public class LikeService {

	public void setLike() {
		// TODO Auto-generated method stub
		
	}

}
