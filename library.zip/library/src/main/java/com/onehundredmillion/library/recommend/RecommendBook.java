package com.onehundredmillion.library.recommend;

import com.onehundredmillion.library.domain.Book;

import java.util.List;

public class RecommendBook {

//    public List<Book> recommend_list()
}