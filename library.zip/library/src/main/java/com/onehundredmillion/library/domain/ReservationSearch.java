package com.onehundredmillion.library.domain;

public class ReservationSearch {

    private String memberName;
    private ReservationStatus reservationStatus;
}